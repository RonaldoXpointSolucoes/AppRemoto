:HL["/_next/static/chunks/0c_9nlwv1zs1w.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"maquinas","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"_5C1kxkE8LKY5hyG4XfoT"}
