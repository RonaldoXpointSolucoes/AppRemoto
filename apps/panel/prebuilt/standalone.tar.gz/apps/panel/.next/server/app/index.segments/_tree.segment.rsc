:HL["/_next/static/chunks/2w_bvxza_or84.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}},"staleTime":300,"buildId":"xmGUYc7jZwI8Nw3Xj7YUn"}
