module.exports=[10857,s=>{"use strict";s.s([])}];

//# sourceMappingURL=044u_panel__next-internal_server_app_api_installer_download_route_actions_1naudxg.js.map