var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/installer/download/route.js")
R.c("server/chunks/[externals]__1n9xchj._.js")
R.c("server/chunks/[root-of-the-server]__0skzlx2._.js")
R.c("server/chunks/[root-of-the-server]__0uvzjl-._.js")
R.c("server/chunks/044u_panel__next-internal_server_app_api_installer_download_route_actions_1naudxg.js")
R.m(98255)
module.exports=R.m(98255).exports
