globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/RRrV3QDH_a-PbjHOwife7/_buildManifest.js",
    "static/RRrV3QDH_a-PbjHOwife7/_ssgManifest.js",
    "static/RRrV3QDH_a-PbjHOwife7/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/2kkv77btj8huu.js",
    "static/chunks/3lvlygum5fy-r.js",
    "static/chunks/1erv62dy5njsx.js",
    "static/chunks/06n66ov0lk2la.js",
    "static/chunks/turbopack-0r5nd4jbp2cu8.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
