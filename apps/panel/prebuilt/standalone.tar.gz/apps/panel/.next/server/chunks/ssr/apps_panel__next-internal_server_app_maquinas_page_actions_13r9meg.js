module.exports=[64525,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_panel__next-internal_server_app_maquinas_page_actions_13r9meg.js.map