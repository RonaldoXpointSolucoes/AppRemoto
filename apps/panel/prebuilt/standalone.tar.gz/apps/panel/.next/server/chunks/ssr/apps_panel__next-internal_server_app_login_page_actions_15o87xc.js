module.exports=[54649,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_panel__next-internal_server_app_login_page_actions_15o87xc.js.map