module.exports=[37321,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_panel__next-internal_server_app_embed_page_actions_0ywa605.js.map