module.exports=[77743,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_panel__next-internal_server_app__global-error_page_actions_05f42go.js.map