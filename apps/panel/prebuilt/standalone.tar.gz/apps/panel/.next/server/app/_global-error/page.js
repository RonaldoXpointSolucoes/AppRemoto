var R=require("../../chunks/ssr/[turbopack]_runtime.js")("server/app/_global-error/page.js")
R.c("server/chunks/ssr/[root-of-the-server]__1w2r_18._.js")
R.c("server/chunks/ssr/07mx_next_dist_0jinpym._.js")
R.c("server/chunks/ssr/[root-of-the-server]__0g_s421._.js")
R.c("server/chunks/ssr/[root-of-the-server]__1e63ngu._.js")
R.c("server/chunks/ssr/07mx_next_dist_client_components_builtin_global-error_00xvc16.js")
R.c("server/chunks/ssr/apps_panel__next-internal_server_app__global-error_page_actions_05f42go.js")
R.m(65999)
module.exports=R.m(65999).exports
