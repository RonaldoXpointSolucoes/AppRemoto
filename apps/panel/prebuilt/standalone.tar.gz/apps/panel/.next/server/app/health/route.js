var R=require("../../chunks/[turbopack]_runtime.js")("server/app/health/route.js")
R.c("server/chunks/[root-of-the-server]__1ff_ei5._.js")
R.c("server/chunks/[root-of-the-server]__0uvzjl-._.js")
R.c("server/chunks/apps_panel__next-internal_server_app_health_route_actions_0fvv63b.js")
R.m(43041)
module.exports=R.m(43041).exports
