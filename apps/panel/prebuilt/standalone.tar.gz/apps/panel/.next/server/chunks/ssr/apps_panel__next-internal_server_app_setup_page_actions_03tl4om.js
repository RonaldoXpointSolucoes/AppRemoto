module.exports=[52135,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_panel__next-internal_server_app_setup_page_actions_03tl4om.js.map