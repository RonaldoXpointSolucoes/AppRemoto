module.exports=[16431,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_panel__next-internal_server_app__not-found_page_actions_1nd6rr4.js.map