module.exports=[35320,s=>{"use strict";s.s([])}];

//# sourceMappingURL=apps_panel__next-internal_server_app_health_route_actions_0fvv63b.js.map