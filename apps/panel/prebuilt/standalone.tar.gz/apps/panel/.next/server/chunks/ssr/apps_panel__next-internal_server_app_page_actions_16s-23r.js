module.exports=[83685,a=>{"use strict";a.s([])}];

//# sourceMappingURL=apps_panel__next-internal_server_app_page_actions_16s-23r.js.map